package com.example.stockcontrol_mvp.network

const val BASE_URL ="https://api.iextrading.com/1.0"
const val END_POINT= "/stock/market/list/gainers"