package com.example.stockcontrol_mvp.model

data class StockData (val symbol:String)